package org.zeroturnaround.exec.stream.slf4j;

/**
 * Slf4j logging level.
 */
public enum Level {

  TRACE,
  DEBUG,
  INFO,
  WARN,
  ERROR

}
